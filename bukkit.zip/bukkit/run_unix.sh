#!/bin/sh
java -Xmx512M -Xms512M -jar craftbukkit-1.5.2-R1.0.jar
